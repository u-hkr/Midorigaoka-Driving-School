<?php

	if ( ! defined( 'ABSPATH' ) ) exit;
	get_header();

	$paged = get_query_var('paged') ? get_query_var('paged') : 1;
	$blog_category_id = get_query_var('blog_category_id') ? get_query_var('blog_category_id') : "100";
?>
	<section class="pageindex blog">
		<div class="container">
			<div class="pageindex-title">
				<h2 class="lead">お知らせ</h2>
				<h3 class="sub">News</h3>
			</div>
		</div>
	</section>

	<div class="pageindex-cat">
		<div class="pageindex-cat-title">
			Select Catcgory
		</div>
		<select name="products_cat" onchange="location = this.value;">
			<option value="<?php echo esc_url(home_url('/')); ?>blog">すべての記事</option>
			<?php
				$all_cats = get_categories([
					'post_type' => 'blog',
					'orderby' => 'post_date',
					'order'   => 'DESC',
					'taxonomy' => 'blog_category',
				]);
				
				foreach ($all_cats as $cat) :?>
				<option value="<?php echo esc_url(home_url('/')); ?>blog?blog_category_id=<?php echo $cat->cat_ID; ?>" <?php if($blog_category_id == $cat->cat_ID): echo 'selected'; endif; ?>><?php echo $cat->name; ?></option>
			<?php endforeach; ?>
		</select>
	</div>

	<section class="p-archive">
		<div class="container">			
			<?php
				$args = [
					'post_type' => 'blog',
					'post_status' => 'publish',
					'paged' => $paged,
					'posts_per_page' => 6,
					'orderby' => 'post_date',
					'order' => "DESC"
				];

				if( !empty($blog_category_id) && ($blog_category_id != 100) ) {
					$args['tax_query'] = [[
						'taxonomy' => 'blog_category',
						'field' => 'term_id',
						'terms' => $blog_category_id
					]];
				}
				$custom_query = new WP_Query( $args );
			?>
			<?php if( $custom_query->have_posts() ) : ?>
				<ul class="blog-card-list">
					<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); 
						$title = mb_strimwidth(strip_tags($post->post_title), 0, 26, "…", "UTF-8");
                        $text = mb_strimwidth(strip_tags($post->post_content), 0, 80, "…", "UTF-8");
					?>
					<li>
						<div class="blog-item">
							<div class="wrap">
								<time class="date"><?php the_time("Y/m/d"); ?></time>
								<?php $blog_cats = get_the_terms(get_the_ID(), 'blog_category'); ?>
								<?php if( $blog_cats ) : ?>
									<div class="label"><?php echo $blog_cats[0]->name; ?></div>
								<?php endif; ?>
							</div>
							<h4 class="title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h4>
							<a href="<?php the_permalink(); ?>" class="more-btn">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/common/post_link.png" alt="">
							</a>
						</div>
					</li>
					<?php endwhile; ?>
				</ui>
			<?php wp_reset_postdata(); ?>
			<?php endif; ?>
		</div>
	</section>

<?php get_footer();?>