<?php
	if ( ! defined( 'ABSPATH' ) ) exit;
	get_header();
	$paged = get_query_var('paged') ? get_query_var('paged') : 1;
	$blog_category_id = get_query_var('blog_category_id') ? get_query_var('blog_category_id') : "100";
?>

	<?php
	if ( have_posts() ) :
		while ( have_posts() ) : the_post();
	?>

	<section class="pageindex blog single">
		<div class="container">
			<div class="pageindex-title">
				<h2 class="lead">News</h2>
				<h3 class="sub">お知らせ</h3>
			</div>
		</div>
		<div class="single-post">
			<div class="single-meta">
				<div class="wrap">
					<?php $blog_cats = get_the_terms(get_the_ID(), 'blog_category'); ?>
					<?php if( $blog_cats ) : ?>
						<div class="label"><?php echo $blog_cats[0]->name; ?></div>
					<?php endif; ?>
					<span></span>
					<time class="date"><?php the_time("Y/m/d"); ?></time>
				</div>
				<h3 class="title"><?php the_title(); ?></h3>
			</div>
			<?php $thumbs = get_field('thumbs'); ?>
			<?php if( $thumbs ) : ?>
				<div class="thumbs">
					<img src="<?php echo esc_url($thumbs[0]['sizes']['small']); ?>" alt="<?php echo esc_html($thumbs[0]['title']); ?>">
				</div>
			<?php endif; ?>
		</div>
	</section>

	<section class="p-single">
		<div class="container">
			<div class="single-content"><?php the_content(); ?></div>
			<div class="single-control">
				<a href="<?php echo HOME . 'blog/' ?>" class="link-btn">
					<span>一覧に戻る</span>
				</a>
			</div>
		</div>
	</section>

	<section class="p-related-article">
		<div class="container">
			<div class="p-related-article-title">
				最新の記事
			</div>
			<?php
				$args = [
					'post_type' => 'blog',
					'post_status' => 'publish',
					'paged' => $paged,
					'posts_per_page' => 3,
					'orderby' => 'post_date',
					'order' => "DESC"
				];

				if( !empty($blog_category_id) && ($blog_category_id != 100) ) {
					$args['tax_query'] = [[
						'taxonomy' => 'blog_category',
						'field' => 'term_id',
						'terms' => $blog_category_id
					]];
				}
				$custom_query = new WP_Query( $args );
			?>
			<?php if( $custom_query->have_posts() ) : ?>
				<ul class="blog-card-list single">
					<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); 
						$title = mb_strimwidth(strip_tags($post->post_title), 0, 26, "…", "UTF-8");
                        $text = mb_strimwidth(strip_tags($post->post_content), 0, 80, "…", "UTF-8");
					?>
					<li>
						<div class="blog-item">
							<div class="wrap">
								<time class="date"><?php the_time("Y/m/d"); ?></time>
								<?php $blog_cats = get_the_terms(get_the_ID(), 'blog_category'); ?>
								<?php if( $blog_cats ) : ?>
									<div class="label"><?php echo $blog_cats[0]->name; ?></div>
								<?php endif; ?>
							</div>
							<h4 class="title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h4>
							<a href="<?php the_permalink(); ?>" class="more-btn">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/common/post_link.png" alt="">
							</a>
						</div>
					</li>
					<?php endwhile; ?>
				</ui>
			<?php wp_reset_postdata(); ?>
			<?php endif; ?>
		</div>
	</section>

	<?php
		endwhile;
	endif;
	?>

<?php get_footer();?>
